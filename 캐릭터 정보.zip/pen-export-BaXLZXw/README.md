# 캐릭터 정보

A Pen created on CodePen.io. Original URL: [https://codepen.io/star1209042/pen/BaXLZXw](https://codepen.io/star1209042/pen/BaXLZXw).

