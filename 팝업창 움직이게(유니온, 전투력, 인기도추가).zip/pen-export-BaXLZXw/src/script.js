window.onload = function() {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1); // 하루 전 날짜 설정

    // 날짜를 'YYYY-MM-DD' 형식으로 변환
    const formattedDate = yesterday.toISOString().slice(0, 10);
    document.getElementById('search-date').value = formattedDate;
    document.getElementById('character-name').value = ''; // 캐릭터 이름 초기화
};

function searchCharacter() {
    const characterName = document.getElementById('character-name').value; // 사용자가 입력한 캐릭터 이름 가져오기
    const searchDate = document.getElementById('search-date').value;

    if (!characterName) {
        alert("캐릭터 이름을 입력해 주세요."); // 입력 검증
        return;
    }

    const headers = {
        "x-nxopen-api-key": "test_657cd016cf4351aaf5ce2014ff9cf2092535ce246f0ffc3d72cf2d4577e69380efe8d04e6d233bd35cf2fabdeb93fb0d" // 발급받은 nxopen_api_key 입력
    }; // 발급받은 nxopen_api_key 입력

    // 첫 번째 요청: 캐릭터 ocid 가져오기
    fetch(`https://open.api.nexon.com/maplestory/v1/id?character_name=${characterName}`, {
        method: "GET",
        headers: headers
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('캐릭터 ID를 불러오는 중 오류가 발생했습니다.');
        }
        return response.json();
    })
    .then(data => {
        const ocid = data.ocid;

        // 두 번째 요청: 캐릭터 기본 정보, 전투력, 인기도, 유니온 정보 가져오기
        return Promise.all([
            fetch(`https://open.api.nexon.com/maplestory/v1/character/basic?ocid=${ocid}`, {
                method: "GET",
                headers: headers
            }).then(res => {
                if (!res.ok) {
                    throw new Error('캐릭터 기본 정보를 불러오는 중 오류가 발생했습니다.');
                }
                return res.json();
            }),
            fetch(`https://open.api.nexon.com/maplestory/v1/character/stat?ocid=${ocid}&date=${searchDate}`, {
                method: "GET",
                headers: headers
            }).then(res => {
                if (!res.ok) {
                    throw new Error('캐릭터 전투력을 불러오는 중 오류가 발생했습니다.');
                }
                return res.json();
            }),
            fetch(`https://open.api.nexon.com/maplestory/v1/character/popularity?ocid=${ocid}&date=${searchDate}`, {
                method: "GET",
                headers: headers
            }).then(res => {
                if (!res.ok) {
                    throw new Error('인기도 정보를 불러오는 중 오류가 발생했습니다.');
                }
                return res.json();
            }),
            fetch(`https://open.api.nexon.com/maplestory/v1/user/union?ocid=${ocid}&date=${searchDate}`, {
                method: "GET",
                headers: headers
            }).then(res => {
                if (!res.ok) {
                    throw new Error('유니온 정보를 불러오는 중 오류가 발생했습니다.');
                }
                return res.json();
            })
        ]);
    })
    .then(([basicData, combatData, popularityData, unionData]) => {
        console.log(basicData, combatData, popularityData, unionData); // 응답 데이터를 콘솔에 출력

        // 기본 정보 HTML에 반영
        document.getElementById('character_name').textContent = basicData.character_name;
        document.getElementById('world_name').textContent = basicData.world_name;
        document.getElementById('character_class').textContent = basicData.character_class;
        document.getElementById('character_level').textContent = basicData.character_level;
        document.getElementById('character_exp_rate').textContent = basicData.character_exp_rate;
        document.getElementById('character_guild_name').textContent = basicData.character_guild_name;
        document.getElementById('character_image').src = basicData.character_image;
        document.getElementById('character-info').style.display = 'block';

        // 인기도 HTML에 반영
        document.getElementById('popularity').textContent = popularityData.popularity;

        // 전투력 찾기
        const combatPowerData = combatData.final_stat.find(stat => stat.stat_name === "전투력");
        
        // 전투력 HTML에 반영
        if (combatPowerData) {
            document.getElementById('combat_power').textContent = combatPowerData.stat_value;
        } else {
            document.getElementById('combat_power').textContent = '전투력을 찾을 수 없습니다.';
        }

        // 유니온 레벨 정보 HTML에 반영
        if (unionData.union_level !== undefined) {
            document.getElementById('union_level').textContent = unionData.union_level;
        } else {
            document.getElementById('union_level').textContent = '유니온 레벨 정보를 찾을 수 없습니다.';
        }

        // 유니온 정보 표시
        document.getElementById('union').style.display = 'block'; // 유니온 정보를 표시
    })
    .catch(error => {
        alert(error.message); // 사용자에게 오류 메시지 표시
        console.error('Error:', error);
    });
}

function closeCharacterInfo() {
    document.getElementById('character-info').style.display = 'none';
}
let isDragging = false;
let offset = { x: 0, y: 0 };

const characterInfo = document.getElementById('character-info');

if (characterInfo) { // 요소가 존재할 때만 이벤트 추가
    // 마우스 클릭 시 드래그 시작
    characterInfo.addEventListener('mousedown', (e) => {
        isDragging = true;

        // 팝업창의 중앙과 클릭한 위치의 차이를 계산
        const rect = characterInfo.getBoundingClientRect();
        offset.x = e.clientX - (rect.left + rect.width / 2);
        offset.y = e.clientY - (rect.top + rect.height / 2);
    });

    // 마우스 이동 시 팝업창 위치 조정
    document.addEventListener('mousemove', (e) => {
        if (isDragging) {
            characterInfo.style.left = `${e.clientX - offset.x}px`;
            characterInfo.style.top = `${e.clientY - offset.y}px`;
            characterInfo.style.position = 'absolute'; // absolute positioning
        }
    });

    // 마우스 버튼 떼기 시 드래그 종료
    document.addEventListener('mouseup', () => {
        isDragging = false;
    });
}
