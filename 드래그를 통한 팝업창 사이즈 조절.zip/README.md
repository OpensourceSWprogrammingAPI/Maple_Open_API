# 팝업 크기조절 추가

A Pen created on CodePen.io. Original URL: [https://codepen.io/star1209042/pen/OPLVoov](https://codepen.io/star1209042/pen/OPLVoov).

